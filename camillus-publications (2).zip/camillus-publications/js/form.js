document.querySelectorAll('.lead-form').forEach(form => {
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                body: formData
            });
            const result = await response.json();
            if (result.success) {
                alert('Thank you for your submission! We have sent your request to our team and will get back to you soon.');
                form.reset();
            } else {
                alert('There was an issue submitting your form. Please try again.');
            }
        } catch (error) {
            alert('An error occurred. Please try again later.');
        }
    });
});