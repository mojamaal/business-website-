// Hamburger Menu Toggle
document.querySelector('.hamburger').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
    const icon = this.querySelector('i');
    icon.classList.toggle('fa-bars');
    icon.classList.toggle('fa-times');
});

// CTA Button Redirect (for "Discover Our Products" button on homepage)
const ctaButton = document.querySelector('.cta-button');
if (ctaButton) {
    ctaButton.addEventListener('click', () => {
        window.location.href = 'products.html';
    });
}

// Smooth Scrolling for Navigation Links
document.querySelectorAll('.nav-links a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const href = this.getAttribute('href');

        // Check if the href is an external link (contains a file extension like .html or a path)
        if (href.includes('.html') || href.includes('/')) {
            window.location.href = href;
        } else {
            // Assume it's an anchor link on the same page (e.g., #section-id)
            const target = document.querySelector(href);
            if (target) {
                window.scrollTo({
                    top: target.offsetTop,
                    behavior: 'smooth'
                });
            } else {
                // Fallback: if the target doesn't exist, redirect to the href
                window.location.href = href;
            }
        }
    });
});