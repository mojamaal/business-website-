<?php
// Manual inclusion of PHPMailer files
require 'vendor/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/src/Exception.php';
require 'vendor/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include database config (optional, currently unused)
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $company = $_POST['company'];
    $product = $_POST['product'];

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Set your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@gmail.com'; // SMTP username (e.g., Gmail address)
        $mail->Password = 'your-app-specific-password'; // SMTP password (use App Password for Gmail with 2FA)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom($email, $name);
        $mail->addAddress('admin@example.com'); // Admin email address
        $mail->addReplyTo($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = "New Lead Inquiry for $product";
        $mail->Body = "
            <h2>New Lead Inquiry</h2>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Company:</strong> $company</p>
            <p><strong>Product:</strong> $product</p>
            <p><strong>Date:</strong> " . date('Y-m-d H:i:s') . " (UTC+0530)</p>
        ";
        $mail->AltBody = "New Lead Inquiry\nName: $name\nEmail: $email\nCompany: $company\nProduct: $product\nDate: " . date('Y-m-d H:i:s') . " (UTC+0530)";

        // Send email
        $mail->send();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $mail->ErrorInfo]);
    }
}
?>